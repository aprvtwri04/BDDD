
package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AbcStepDefinition {

@Given("^User is using the banking app$")
public void user_is_using_the_banking_app() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^User use the change pinNumber feature$")
public void user_use_the_change_pinNumber_feature() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^User get to access his atm using the changed pinNumber$")
public void user_get_to_access_his_atm_using_the_changed_pinNumber() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

}
